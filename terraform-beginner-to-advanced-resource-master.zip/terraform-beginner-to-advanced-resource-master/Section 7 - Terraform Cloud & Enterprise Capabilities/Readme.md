# Domain  - Terraform Cloud & Enterprise Capabilities

The code mentioned in this document are used in the HashiCorp Certified Terraform Associate 2024 video course.


# Video-Document Mapper

| Sr No | Document Link |
| ------ | ------ |
| 1 | [HCP Terraform - Core Practical][PlDa] |
| 2 | [Overview of Sentinel][PlDb] |
| 3 | [Implementing Remote Backend Operations][PlDc] |




   [PlDa]: <./terraform-cloud.md>
   [PlDb]: <./sentinel.md>
   [PlDc]: <./remote-backend.md>
