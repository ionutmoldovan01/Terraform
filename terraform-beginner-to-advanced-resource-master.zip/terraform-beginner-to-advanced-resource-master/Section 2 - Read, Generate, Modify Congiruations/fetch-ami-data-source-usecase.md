### Base Code used:

```sh
resource "aws_instance" "web" {
  ami           = ""
  instance_type = "t2.micro"
}
```