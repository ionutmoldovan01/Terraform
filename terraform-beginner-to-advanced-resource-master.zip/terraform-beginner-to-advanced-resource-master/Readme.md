## HashiCorp Certified Terraform: Associate

This Git repository contains all the code files used throughout the HashiCorp Certified Terraform Associate course by Zeal Vora.

We also have a new Discord community for any support related discussion as well as to connect to other students doing the same course. Feel free to join the community.

```sh
https://kplabs.in/chat
```

Welcome to the community again, and we look forward to seeing you certified! :)

<p align="center">
  <img width="460" height="300" src="https://i.ibb.co/b3jFkkk/discord-terraform.png">
</p>
